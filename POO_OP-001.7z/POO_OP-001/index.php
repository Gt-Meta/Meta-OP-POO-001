<?php
$produto = new Produto();
$produto->setDescricao('Produto_001');
$produto->setPreco(5.55);
$produto->setQuantidade(99);
$produto->adicionar();
?>
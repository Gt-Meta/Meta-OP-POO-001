<?php
class Produto {
    protected $id;
    protected $descricao;
    protected $preco;
    protected $quantidade;

public function setId($d) {
        $this->id = $d;
}  

public function setDescricao($d) {
    $this->descriçao = $d;
}

public function setPreco($d) {
    $this->preço = $d;
}

public function setQuantidade($d) {
    $this->quantidade = $d;
}

public function adicionar() {
$sql="INSERT INTO produto
(descrição, preço, quantidade
values(?, ?, ?)";

try {

$con=OP_DB::conexao();
$stmt=$con->preapre($sql);

$stmt->bindParam(1, $this->getDescricao());
$stmt->bindParam(2, $this->getPreco());
$stmt->bindParam(3, $this->getQuantidade());


$con = OP_DB::conexao();
$stmt = $conexao->prepare($sql);

}catch(PDOException $e){
echo "Erro ao Adicionar Produto" . $e->getMessage();
$e->getMessage;
}

}

public function listar() {
    $sql = "SELECT * FROM produto";
    $produtos = array();
    try{
        $con = OP_DB::conexao();
        $stmt = $conexao->prepare($sql);
        $stmt->execute();
        $registros = $stmt->fetchAll();

        foreach($registros as $registro) {
            $temp = new Produto();
            $temp->setId($registro["id"]);
            $temp->setDescricao($registro["descricao"]);
            $temp->setPreco($registro["preco"]);
            $temp->setQuantidade($registro["quantidade"]);
            
            $produtos[] = $temp;
        }

}catch(PDOException $e){
echo "Erro na Listagem dos Produtos:"
. $e->getMessage();

return $produtos;
}

}

public function atualizar() {

}

public function excluir() {

}

}
?>
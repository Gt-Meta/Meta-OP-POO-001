class Produto {
    protected $id;
    protected $descriçao;
    protected $preço;
    protected $quantidade;
}

public function setDescriçao($d) {
    $this->descriçao = $d;
}


public function adicionar() {
$sql="INSERT INTO produto
(descrição, preço, quantidade)"
values(?, ?, ?)

try {

$con=DB::conexao()
$stmt=$con->preapre($sql)

$this-bindParam(1) this->getDescriçao()
$this-bindParam(2) this->getPreço()
$this-bindParam(3) this->getQuantidade()

}catch(PDOException $e){
echo "Erro ao Adicionar Produto" . $e->getMessage();
$e->getMessage
}

}
}
public function listar() {

}

public function atualizar() {

}

public function excluir() {

}

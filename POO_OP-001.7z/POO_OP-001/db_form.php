<form method="POST" action="">
Produto: 
<input type="text" name="descricao" /><br />
Preço: 
<input type="text" name="preco" /><br />
<br>
<input type="submit" name="botao" value="Salvar" />
</form>

<?php

if(isset($_POST["botao"]) && $_POST["botao"] == "Salvar" ){

$produto = new Produto();
$produto->setDescricao($_POST['descricao']);
$produto->setPreco($_POST['preco']);
}


?>
<?php
if(isset($_POST["botao"]) && $_POST["botao"] == "Salvar"  ){
$produto = new Produto();
$produto->setDescricao($_POST['descrição']);
$produto->setPreco($_POST['preco']);
$produto->setQuantidade(99);
$produto->adicionar();
}
?>
<?php
if(isset($_GET["id"]) && is_numeric($_GET["id"])){
$produto= new Produto($_GET["id"]);
$produto->excluir();
}
?>
<?php

$produtos = Produto::listar();
foreach($produtos as $produto){
$id = $produto->getId();
$descricao = $produto->getDescricao();
$preco = $produto->getPreco();
$quantidade = $produto->getQuantidade();
echo $id, $descricao, $preco, $quantidade;
}

?>